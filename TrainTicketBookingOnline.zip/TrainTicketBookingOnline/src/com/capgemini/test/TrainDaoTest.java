package com.capgemini.test;



import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.TrainException;



public class TrainDaoTest {

	static  TrainDaoImpl tdaoimpl;
	static BookingBean bookingbean;
	
	@BeforeClass
	public static void intialize() throws TrainException{
		
		tdaoimpl=new TrainDaoImpl();
		bookingbean = new BookingBean();
	}
	
	@Test 
	public  void testBookTicket() throws TrainException{
		bookingbean.setBookingId(1034);
		bookingbean.setCustId("B746746");
		bookingbean.setNoOfSeat(7);
		bookingbean.setTrainId(2);
		assertNotNull("Booked", tdaoimpl.bookTicket(bookingbean)>1000);
	}
	
	@Test
	public void testBookId() throws TrainException{
		
		int tid=tdaoimpl.generateBookingId();
		assertEquals("Test Correct",tid+1,tdaoimpl.generateBookingId());
	}
	@Test
	public void  testTrainDetails() throws TrainException{
		
		assertNotNull(tdaoimpl.retrieveTrainDetails());
	}
	

}
