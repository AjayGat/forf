package com.capgemini.client;

import java.util.List;
import java.util.Scanner;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.TrainException;
import com.capgemini.service.ITrainService;
import com.capgemini.service.TrainServiceImpl;



public class MainClient {

	public static void main(String[] args) {
		ITrainService service = new TrainServiceImpl();
		Scanner scanner = new Scanner(System.in);
		do {
			
			System.out.println("1.Book Ticket");
			System.out.println("2.Exit");
			System.out.println("Please Enter Your Choice");
			String choice = scanner.next();
			switch (choice) {
			case "1":

				try {
					List<TrainBean> tli = service.retrieveTrainDetails();
					if (tli.size() == 0) {
						System.err.println("No trains available\n");
					} else {
						for (TrainBean t : tli) {
							System.out.println(t);
						}
					}
				} catch (TrainException e) {
					System.err
							.println("Unable to show list\n" + e.getMessage());
				}
				System.out.println("Please Enter Customer Id:");
				String custId = scanner.next();
				System.out.println("Please Enter Train Id:");
				int trainId = scanner.nextInt();
				System.out.println("Please Enter Number of Seats");
				int noOfSeat = scanner.nextInt();
				BookingBean bookingbean = new BookingBean(noOfSeat, trainId,
						custId);
				try {
					int bookid = service.bookTicket(bookingbean);
					System.out.println("your Booking Id is: "+bookid);
				} catch (TrainException e) {
					System.out.println(e.getMessage());
				}

				break;

			case "2":
					System.exit(0);
				break;

			default:
				System.out.println("Please Enter Correct Input");
				break;
			}
		} while (true);

	}

}
