package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.ITrainDao;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.TrainException;



public class TrainServiceImpl implements ITrainService {
	ITrainDao dao = new TrainDaoImpl();

	@Override
	public List<TrainBean> retrieveTrainDetails() throws TrainException {
		
		return dao.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws TrainException {
		// TODO Auto-generated method stub
	return dao.bookTicket(bookingbean);
	}

	

}
