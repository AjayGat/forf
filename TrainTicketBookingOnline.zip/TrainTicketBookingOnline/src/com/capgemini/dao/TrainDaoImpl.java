package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.TrainException;
import com.capgemini.util.DBUtil;



public class TrainDaoImpl implements ITrainDao {
	Connection conn = null;

	@Override
	public List<TrainBean> retrieveTrainDetails() throws TrainException {
		List<TrainBean> trainList = new ArrayList<TrainBean>();
		conn = DBUtil.getConnection();
		Statement stmt;
		try {
			stmt = conn.createStatement();
			ResultSet rst = stmt
					.executeQuery(QueryMapper.Get_ALL_TRAINDETAILS);
			while (rst.next()) {
				TrainBean trainbe = new TrainBean();
				trainbe.setTrainId(rst.getInt(1));
				trainbe.setTrainType(rst.getString(2));
				trainbe.setFromStop(rst.getString(3));
				trainbe.setToStop(rst.getString(4));
				trainbe.setFare(rst.getInt(5));
				trainbe.setAvailableSeats(rst.getInt(6));
				trainbe.setDateOfJourney(rst.getDate(7));
				trainList.add(trainbe);
			}

		} catch (SQLException e) {
			throw new TrainException("Prolem in Fetching TrainDetail list");
		}
		return trainList;
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws TrainException {
		bookingbean.setBookingId(generateBookingId());
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn
					.prepareStatement(QueryMapper.INSERT_ALL_BOOKING_DETAILS);
			pst.setInt(1, bookingbean.getBookingId());
			pst.setString(2, bookingbean.getCustId());
			pst.setInt(3, bookingbean.getTrainId());
			pst.setInt(4, bookingbean.getNoOfSeat());
			int update = pst.executeUpdate();
			if (update == 1) {
				String sql1 = "select availableseats from traindetails where trainid=?";
				PreparedStatement statement2 = conn.prepareStatement(sql1);
				statement2.setInt(1, bookingbean.getTrainId());
				ResultSet set = statement2.executeQuery();
				int availableseats = 0;
				while (set.next()) {
					availableseats = set.getInt(1);
				}
				String sql = "Update traindetails set availableseats=? where trainid=?";
				PreparedStatement statement = conn.prepareStatement(sql);
				statement.setInt(1, availableseats - bookingbean.getNoOfSeat());
				statement.setInt(2, bookingbean.getTrainId());
				statement.executeUpdate();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return bookingbean.getBookingId();
	}

	public int generateBookingId() throws TrainException {
		int bid = 0;
		try {
			conn = DBUtil.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rst;
			rst = stmt.executeQuery(QueryMapper.GENERATE_BOOKINGID);
			while (rst.next()) {
				bid = rst.getInt(1);
			}
		} catch (SQLException e) {
			throw new TrainException("Problem in generating Booking id");
		}
		return bid;

	}

}