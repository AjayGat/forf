package com.capgemini.bean;

public class BookingBean {

	private int bookingId;
	private int noOfSeat;
	private int trainId;
	private String custId;

	
	public BookingBean() {
		// TODO Auto-generated constructor stub
	}


	public BookingBean(int noOfSeat, int trainId, String custId) {
		super();
	
		this.noOfSeat = noOfSeat;
		this.trainId = trainId;
		this.custId = custId;
	}


	public int getBookingId() {
		return bookingId;
	}


	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}


	public int getNoOfSeat() {
		return noOfSeat;
	}


	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}


	public int getTrainId() {
		return trainId;
	}


	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}


	public String getCustId() {
		return custId;
	}


	public void setCustId(String custId) {
		this.custId = custId;
	}


	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", noOfSeat=" + noOfSeat
				+ ", trainId=" + trainId + ", custId=" + custId + "]";
	}
	

}
