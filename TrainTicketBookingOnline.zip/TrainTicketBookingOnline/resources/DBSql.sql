Set A : Table Script
CREATE TABLE TrainDetails(trainId NUMBER PRIMARY KEY, trainType VARCHAR(20), fromStop VARCHAR(20),toStop VARCHAR(20),fare DECIMAL, availableSeats NUMBER, dateOfJourney DATE);

INSERT INTO TrainDetails VALUES (1,'AC chair car','Mumbai','Pune',420,30, '27-Aug-2016');
INSERT INTO TrainDetails VALUES (2,'Non ac chair car','Pune','Mumbai',420,30, '27-Aug-2016');
INSERT INTO TrainDetails VALUES (3,'Sleeper i','Mumbai','Chennai',1000,30, '1-Sep-2016');
   
CREATE TABLE BookingDetails(bookingId NUMBER PRIMARY KEY,custId VARCHAR2(10), trainId REFERENCES TrainDetails(trainId),noOfSeats Number);

Note: bookingId should get generated using sequence.
CREATE SEQUENCE Booking_Id_Seq start with 1001;
------------------------------------------------------------------------------------------------------------------------------------
